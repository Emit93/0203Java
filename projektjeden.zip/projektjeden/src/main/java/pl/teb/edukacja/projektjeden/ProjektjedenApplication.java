package pl.teb.edukacja.projektjeden;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjektjedenApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjektjedenApplication.class, args);
	}

}
